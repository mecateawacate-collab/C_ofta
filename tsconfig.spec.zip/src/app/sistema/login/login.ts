import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  usuario = '';
  clave = '';
  mensajeError = '';
  mostrarClave = false;

  constructor(private router: Router) {}

  ingresar() {
    const usuarioLimpio = this.usuario.trim();
    const claveLimpia = this.clave.trim();

    if (usuarioLimpio === 'admin' && claveLimpia === '123') {
      this.mensajeError = '';
      this.router.navigate(['/menu']);
      return;
    }

    this.mensajeError = 'Usuario o contraseña incorrectos.';
  }
}